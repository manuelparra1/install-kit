# Manny Lazy Nvim Setup

## Plugins Used

zk-nvim
Floaterm
Lualine
Bufferline

#vim #plugins
