return {
	"christoomey/vim-tmux-navigator",
}
