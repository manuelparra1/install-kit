--return {
--	"bluz71/vim-nightfly-guicolors",
--	lazy = false,
--	priority = 1000,
--	opts = {},
--	config = function()
--		vim.cmd([[colorscheme nightfly]])
--	end,
--}
return {
	"catppuccin/nvim",
	name = "catppuccin",
	priority = 1000,
	config = function()
		vim.cmd([[colorscheme catppuccin-frappe]])
	end,
}
--return {
--	"Mofiqul/dracula.nvim",
--	lazy = false,
--	priority = 1000,
--	opts = {},
--	config = function()
--		vim.cmd([[colorscheme dracula]])
--	end,
--}
