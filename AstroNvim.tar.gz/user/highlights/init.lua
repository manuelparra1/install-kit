return { -- this table overrides highlights in all themes
  -- Normal = { bg = "#000000" },
}
